import java.util.*;

public class AncestryResult {
    private final Map<String, Double> ancestryComposition;
    private final String closestMatch;
    private final double confidence;
    private final int snpsAnalyzed;

    public AncestryResult(Map<String, Double> ancestryComposition) {
        this.ancestryComposition = Collections.unmodifiableMap(ancestryComposition);
        this.closestMatch = calculateClosestMatch();
        this.confidence = calculateConfidence();
        this.snpsAnalyzed = ancestryComposition.size();
    }

    private String calculateClosestMatch() {
        return ancestryComposition.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("Unknown");
    }

    private double calculateConfidence() {
        List<Double> values = new ArrayList<>(ancestryComposition.values());
        if (values.size() < 2) return 100.0;

        Collections.sort(values, Collections.reverseOrder());
        double highest = values.get(0);
        double secondHighest = values.get(1);

        return highest - secondHighest;
    }

    public Map<String, Double> getAncestryComposition() {
        return ancestryComposition;
    }

    public String getClosestMatch() {
        return closestMatch;
    }

    public double getConfidence() {
        return confidence;
    }

    public int getSnpsAnalyzed() {
        return snpsAnalyzed;
    }

    public String getFormattedResults() {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════════\n");
        sb.append("           ANCESTRY ANALYSIS REPORT        \n");
        sb.append("═══════════════════════════════════════════\n\n");

        sb.append("SUMMARY\n");
        sb.append("• Closest Match: ").append(closestMatch).append("\n");
        sb.append(String.format("• Confidence Score: %.1f%%\n", confidence));
        sb.append("• SNPs Analyzed: ").append(snpsAnalyzed).append("\n\n");

        sb.append("DETAILED COMPOSITION\n");
        sb.append("────────────────────\n");

        for (Map.Entry<String, Double> entry : ancestryComposition.entrySet()) {
            if (entry.getValue() > 1.0) {
                sb.append(String.format("• %-18s: %5.1f%%\n",
                        entry.getKey(), entry.getValue()));
            }
        }

        sb.append("\nINTERPRETATION\n");
        sb.append("──────────────\n");

        if (confidence > 30) {
            sb.append("Strong genetic match to ").append(closestMatch).append(" population.\n");
        } else if (confidence > 15) {
            sb.append("Moderate match to ").append(closestMatch).append(" population.\n");
            sb.append("Possible mixed ancestry detected.\n");
        } else {
            sb.append("Mixed ancestry detected with no clear majority.\n");
            sb.append("Further analysis recommended.\n");
        }

        return sb.toString();
    }
}