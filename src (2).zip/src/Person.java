import java.time.LocalDate;

public class Person {
    private final String id;
    private final String name;
    private final Sex sex;
    private final LocalDate birthDate;
    private DNASequence dnaSequence;

    public Person(String id, String name, Sex sex, LocalDate birthDate) {
        this(id, name, sex, birthDate, new DNASequence(""));
    }

    public Person(String id, String name, Sex sex, LocalDate birthDate, DNASequence dnaSequence) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.birthDate = birthDate;
        this.dnaSequence = dnaSequence;
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public Sex getSex() { return sex; }
    public LocalDate getBirthDate() { return birthDate; }
    public DNASequence getDnaSequence() { return dnaSequence; }

    public void setDnaSequence(DNASequence dnaSequence) {
        this.dnaSequence = dnaSequence;
    }

    public int getAge() {
        return LocalDate.now().getYear() - birthDate.getYear();
    }

    @Override
    public String toString() {
        return String.format("%s (ID: %s, %s, Age: %d, DNA Length: %d bp)",
                name, id, sex, getAge(), dnaSequence.length());
    }

    public enum Sex {
        MALE, FEMALE, UNKNOWN
    }
}