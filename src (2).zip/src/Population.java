import java.util.*;

public class Population {
    private final String name;
    private final String region;
    private final Map<String, SNPFrequency> snpFrequencies;

    public Population(String name, String region) {
        this.name = name;
        this.region = region;
        this.snpFrequencies = new HashMap<>();
    }

    public void addSNP(String rsid, char commonAllele, double frequency) {
        snpFrequencies.put(rsid, new SNPFrequency(rsid, commonAllele, frequency));
    }

    public SNPFrequency getSNP(String rsid) {
        return snpFrequencies.get(rsid);
    }

    public char getCommonAllele(String rsid) {
        SNPFrequency snp = snpFrequencies.get(rsid);
        return snp != null ? snp.commonAllele : 'N';
    }

    public double getFrequency(String rsid) {
        SNPFrequency snp = snpFrequencies.get(rsid);
        return snp != null ? snp.frequency : 0.0;
    }

    public boolean hasSNP(String rsid) {
        return snpFrequencies.containsKey(rsid);
    }

    public Set<String> getSNPIds() {
        return snpFrequencies.keySet();
    }

    public String getName() {
        return name;
    }

    public String getRegion() {
        return region;
    }

    @Override
    public String toString() {
        return name + " (" + region + ", SNPs: " + snpFrequencies.size() + ")";
    }

    public static class SNPFrequency {
        public final String rsid;
        public final char commonAllele;
        public final double frequency;

        public SNPFrequency(String rsid, char commonAllele, double frequency) {
            this.rsid = rsid;
            this.commonAllele = commonAllele;
            this.frequency = frequency;
        }
    }
}