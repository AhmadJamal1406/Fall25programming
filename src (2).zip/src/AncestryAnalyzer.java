import java.util.*;

public class AncestryAnalyzer {
    private final PopulationDatabase database;

    public AncestryAnalyzer() {
        this.database = PopulationDatabase.getInstance();
    }

    public AncestryResult analyze(AncestryDNA dna) {
        Map<String, Double> scores = new HashMap<>();

        for (String popName : database.getAllPopulationNames()) {
            scores.put(popName, 0.0);
        }

        for (String popName : database.getAllPopulationNames()) {
            double score = calculatePopulationScore(dna, popName);
            scores.put(popName, score);
        }

        return new AncestryResult(normalizeScores(scores));
    }

    private double calculatePopulationScore(AncestryDNA dna, String populationName) {
        Population population = database.getPopulation(populationName);
        if (population == null) return 0.0;

        double totalScore = 0.0;
        int snpsChecked = 0;

        for (Map.Entry<String, char[]> entry : dna.getSnpProfile().entrySet()) {
            String rsid = entry.getKey();
            char[] alleles = entry.getValue();

            Population.SNPFrequency snpData = population.getSNP(rsid);
            if (snpData != null) {
                snpsChecked++;

                double alleleScore = 0.0;
                if (alleles[0] == snpData.commonAllele) {
                    alleleScore += snpData.frequency;
                }
                if (alleles[1] == snpData.commonAllele) {
                    alleleScore += snpData.frequency;
                }

                totalScore += alleleScore / 2.0;
            }
        }

        return snpsChecked > 0 ? (totalScore / snpsChecked) * 100 : 0.0;
    }

    private Map<String, Double> normalizeScores(Map<String, Double> scores) {
        Map<String, Double> normalized = new LinkedHashMap<>();
        double total = scores.values().stream().mapToDouble(Double::doubleValue).sum();

        if (total > 0) {
            for (Map.Entry<String, Double> entry : scores.entrySet()) {
                normalized.put(entry.getKey(), (entry.getValue() / total) * 100);
            }
        }

        return sortByValue(normalized);
    }

    private Map<String, Double> sortByValue(Map<String, Double> map) {
        List<Map.Entry<String, Double>> list = new ArrayList<>(map.entrySet());
        list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        Map<String, Double> sorted = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : list) {
            sorted.put(entry.getKey(), entry.getValue());
        }
        return sorted;
    }

    public String analyzeSimple(DNASequence dna) {
        AncestryDNA ancestryDNA = new AncestryDNA("Sample", dna);
        AncestryResult result = analyze(ancestryDNA);
        return result.getClosestMatch();
    }

    public List<String> getReferencePopulations() {
        return database.getAllPopulationNames();
    }
}