import java.util.*;

public class AncestryDNA {
    private final String personName;
    private final Map<String, char[]> snpProfile;
    private final DNASequence dnaSequence;

    public AncestryDNA(String personName) {
        this.personName = personName;
        this.snpProfile = new HashMap<>();
        this.dnaSequence = null;
    }

    public AncestryDNA(String personName, DNASequence dnaSequence) {
        this.personName = personName;
        this.dnaSequence = dnaSequence;
        this.snpProfile = extractSNPsFromDNA(dnaSequence);
    }

    public void addSNP(String rsid, char allele1, char allele2) {
        snpProfile.put(rsid, new char[]{allele1, allele2});
    }

    private Map<String, char[]> extractSNPsFromDNA(DNASequence dna) {
        Map<String, char[]> extractedSNPs = new HashMap<>();
        String sequence = dna.getSequence();

        if (sequence.contains("AGCT")) {
            extractedSNPs.put("rs1426654", new char[]{'A', 'A'});
        }
        if (sequence.contains("TCGA")) {
            extractedSNPs.put("rs4988235", new char[]{'T', 'T'});
        }
        if (sequence.contains("GATC")) {
            extractedSNPs.put("rs2814778", new char[]{'C', 'C'});
        }
        if (sequence.contains("CTAG")) {
            extractedSNPs.put("rs12913832", new char[]{'G', 'G'});
        }
        if (sequence.contains("ATCG")) {
            extractedSNPs.put("rs12203592", new char[]{'C', 'T'});
        }

        return extractedSNPs;
    }

    public Map<String, char[]> getSnpProfile() {
        return Collections.unmodifiableMap(snpProfile);
    }

    public String getPersonName() {
        return personName;
    }

    public DNASequence getOriginalDNA() {
        return dnaSequence;
    }

    @Override
    public String toString() {
        int snpCount = snpProfile.size();
        return personName + " [SNPs: " + snpCount + "]";
    }
}