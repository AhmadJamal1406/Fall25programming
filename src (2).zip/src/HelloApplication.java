import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class HelloApplication extends Application {

    private List<Person> personDatabase = new ArrayList<>();
    private Stage primaryStage;

    // Modern color scheme
    private static final String PRIMARY = "#1A237E";
    private static final String SECONDARY = "#303F9F";
    private static final String ACCENT = "#00B0FF";
    private static final String SUCCESS = "#00C853";
    private static final String WARNING = "#FF9100";
    private static final String DANGER = "#FF5252";
    private static final String BACKGROUND = "#F5F7FA";
    private static final String CARD_BG = "#FFFFFF";
    private static final String TEXT_PRIMARY = "#263238";
    private static final String TEXT_SECONDARY = "#607D8B";
    private static final String BORDER = "#E0E0E0";

    // Screen dimensions for laptop
    private static final double SCREEN_WIDTH = 1366;
    private static final double SCREEN_HEIGHT = 768;

    // Font sizes for laptop screen
    private static final double TITLE_SIZE = 18.0;
    private static final double SUBTITLE_SIZE = 14.0;
    private static final double BODY_SIZE = 12.5;
    private static final double SMALL_SIZE = 11.0;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("🧬 GenoLab DNA Analyzer");
        primaryStage.setWidth(SCREEN_WIDTH * 0.9);
        primaryStage.setHeight(SCREEN_HEIGHT * 0.9);
        primaryStage.setMaximized(true);

        // Create main container
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: " + BACKGROUND + ";");

        // Header
        HBox header = createHeader();
        root.setTop(header);

        // Center with tabs
        TabPane tabPane = createTabPane();
        root.setCenter(tabPane);

        // Status bar
        HBox statusBar = createStatusBar();
        root.setBottom(statusBar);

        Scene scene = new Scene(root);
        scene.setFill(Color.TRANSPARENT);

        // Global CSS
        String globalCSS =
                ".tab-pane .tab-header-area .tab-header-background {\n" +
                        "    -fx-background-color: linear-gradient(to right, " + PRIMARY + ", " + SECONDARY + ");\n" +
                        "}\n" +
                        ".tab-pane .tab {\n" +
                        "    -fx-background-color: " + CARD_BG + ";\n" +
                        "    -fx-background-radius: 8 8 0 0;\n" +
                        "    -fx-border-color: " + BORDER + ";\n" +
                        "    -fx-border-radius: 8 8 0 0;\n" +
                        "    -fx-padding: 8 15;\n" +
                        "    -fx-font-size: " + BODY_SIZE + "px;\n" +
                        "    -fx-font-weight: 500;\n" +
                        "}\n" +
                        ".tab-pane .tab:selected {\n" +
                        "    -fx-background-color: white;\n" +
                        "    -fx-border-color: " + ACCENT + ";\n" +
                        "    -fx-border-width: 0 0 3 0;\n" +
                        "    -fx-text-fill: " + ACCENT + ";\n" +
                        "}\n" +
                        ".tab-pane .tab:hover {\n" +
                        "    -fx-background-color: #F8F9FA;\n" +
                        "}\n" +
                        ".scroll-pane {\n" +
                        "    -fx-background-color: transparent;\n" +
                        "    -fx-border-color: transparent;\n" +
                        "}\n" +
                        ".scroll-pane .viewport {\n" +
                        "    -fx-background-color: transparent;\n" +
                        "}\n" +
                        ".scroll-bar:vertical {\n" +
                        "    -fx-background-color: transparent;\n" +
                        "    -fx-pref-width: 8;\n" +
                        "}\n" +
                        ".scroll-bar:vertical .thumb {\n" +
                        "    -fx-background-color: rgba(0, 0, 0, 0.1);\n" +
                        "    -fx-background-radius: 4;\n" +
                        "}\n" +
                        ".scroll-bar:vertical .thumb:hover {\n" +
                        "    -fx-background-color: rgba(0, 0, 0, 0.2);\n" +
                        "}\n";

        // Add the CSS to the root
        root.setStyle(root.getStyle() + globalCSS);
        primaryStage.setScene(scene);

        // Center window
        primaryStage.centerOnScreen();
        primaryStage.show();

        // Fade in animation
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.8), root);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();
    }

    private HBox createHeader() {
        HBox header = new HBox(15);
        header.setPadding(new Insets(10, 20, 10, 20));
        header.setStyle("-fx-background-color: " + PRIMARY + ";");
        header.setAlignment(Pos.CENTER_LEFT);

        // Logo
        Label logo = new Label("🧬");
        logo.setFont(Font.font("Segoe UI Emoji", 24));
        logo.setTextFill(Color.WHITE);

        // Title
        VBox titleBox = new VBox(2);
        Label title = new Label("GenoLab DNA Suite");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.WHITE);

        Label subtitle = new Label("Professional DNA Analysis Platform");
        subtitle.setFont(Font.font("Segoe UI", SMALL_SIZE));
        subtitle.setTextFill(Color.web("#B0BEC5"));

        titleBox.getChildren().addAll(title, subtitle);

        // Spacer
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Quick actions
        HBox actions = new HBox(10);
        actions.setAlignment(Pos.CENTER_RIGHT);

        Button helpBtn = createFlatButton("?", ACCENT);
        helpBtn.setPrefSize(30, 30);

        Button settingsBtn = createFlatButton("⚙️", TEXT_SECONDARY);
        settingsBtn.setPrefSize(30, 30);

        Button exportBtn = createModernButton("📤 Export", SUCCESS);
        exportBtn.setPrefHeight(30);

        actions.getChildren().addAll(helpBtn, settingsBtn, exportBtn);

        header.getChildren().addAll(logo, titleBox, spacer, actions);
        return header;
    }

    private HBox createStatusBar() {
        HBox statusBar = new HBox(10);
        statusBar.setPadding(new Insets(6, 20, 6, 20));
        statusBar.setStyle("-fx-background-color: " + CARD_BG + "; " +
                "-fx-border-color: " + BORDER + "; " +
                "-fx-border-width: 1 0 0 0;");
        statusBar.setAlignment(Pos.CENTER_LEFT);

        Label status = new Label("✅ Ready | Database: " + personDatabase.size() + " profiles | v2.1");
        status.setFont(Font.font("Segoe UI", SMALL_SIZE));
        status.setTextFill(Color.web(TEXT_SECONDARY));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label time = new Label(LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy • HH:mm")));
        time.setFont(Font.font("Segoe UI", SMALL_SIZE));
        time.setTextFill(Color.web(TEXT_SECONDARY));

        statusBar.getChildren().addAll(status, spacer, time);
        return statusBar;
    }

    private TabPane createTabPane() {
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setStyle("-fx-background-color: transparent; -fx-tab-min-height: 40;");

        Tab[] tabs = {
                createTab("🧬 DNA", createDNAAnalysisTab()),
                createTab("🌍 Ancestry", createAncestryTab()),
                createTab("👨‍👩‍👦 Paternity", createPaternityTab()),
                createTab("⚕️ Disease", createDiseaseTab()),
                createTab("🔍 Forensic", createForensicTab()),
                createTab("💊 Pharma", createPharmacoTab()),
                createTab("💾 Database", createDatabaseTab()),
                createTab("📊 Reports", createReportsTab())
        };

        tabPane.getTabs().addAll(tabs);
        return tabPane;
    }

    private Tab createTab(String title, ScrollPane content) {
        Tab tab = new Tab(title);
        tab.setContent(content);
        tab.setStyle("-fx-padding: 5 15;");
        return tab;
    }

    // ========== DNA ANALYSIS TAB ==========
    private ScrollPane createDNAAnalysisTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background-color: " + BACKGROUND + ";");

        // Header with actions
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        VBox titleBox = new VBox(3);
        Label title = new Label("DNA Sequence Analysis");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        Label subtitle = new Label("Analyze and visualize DNA sequences");
        subtitle.setFont(Font.font("Segoe UI", SMALL_SIZE));
        subtitle.setTextFill(Color.web(TEXT_SECONDARY));
        titleBox.getChildren().addAll(title, subtitle);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox actionButtons = new HBox(8);
        Button sampleBtn = createSmallButton("Sample", SECONDARY);
        Button clearBtn = createSmallButton("Clear", DANGER);
        actionButtons.getChildren().addAll(sampleBtn, clearBtn);

        header.getChildren().addAll(titleBox, spacer, actionButtons);

        // Main content in two columns
        HBox mainContent = new HBox(15);
        mainContent.setAlignment(Pos.TOP_LEFT);

        // Left column - Input
        VBox leftColumn = new VBox(15);
        leftColumn.setPrefWidth(SCREEN_WIDTH * 0.35);

        VBox inputCard = createCard("DNA Input");
        TextArea dnaInput = createTextArea("Enter DNA sequence (ATCG...)", 6);
        dnaInput.setWrapText(true);

        HBox inputStats = new HBox(15);
        Label lengthLabel = new Label("Length: 0");
        lengthLabel.setFont(Font.font("Segoe UI", SMALL_SIZE));
        lengthLabel.setTextFill(Color.web(TEXT_SECONDARY));

        Label gcLabel = new Label("GC: 0%");
        gcLabel.setFont(Font.font("Segoe UI", SMALL_SIZE));
        gcLabel.setTextFill(Color.web(TEXT_SECONDARY));

        inputStats.getChildren().addAll(lengthLabel, gcLabel);

        Button analyzeBtn = createModernButton("🧬 Analyze DNA", ACCENT);
        analyzeBtn.setMaxWidth(Double.MAX_VALUE);

        inputCard.getChildren().addAll(dnaInput, inputStats, analyzeBtn);

        // Right column - Results
        VBox rightColumn = new VBox(15);
        rightColumn.setPrefWidth(SCREEN_WIDTH * 0.35);

        VBox resultsCard = createCard("Analysis Results");
        TextArea resultsArea = createTextArea("", 12);
        resultsArea.setEditable(false);
        resultsCard.getChildren().add(resultsArea);

        // Update labels in real-time
        dnaInput.textProperty().addListener((obs, old, newVal) -> {
            try {
                DNASequence dna = new DNASequence(newVal);
                lengthLabel.setText("Length: " + dna.length());
                gcLabel.setText("GC: " + String.format("%.1f", dna.getGCContent()) + "%");
            } catch (Exception e) {
                lengthLabel.setText("Length: 0");
                gcLabel.setText("GC: 0%");
            }
        });

        // Analysis button action
        analyzeBtn.setOnAction(e -> {
            try {
                DNASequence dna = new DNASequence(dnaInput.getText());

                StringBuilder sb = new StringBuilder();
                sb.append("═ DNA ANALYSIS REPORT ═══════════════\n\n");
                sb.append("SEQUENCE PROPERTIES\n");
                sb.append("• Length: ").append(dna.length()).append(" bp\n");
                sb.append("• GC Content: ").append(String.format("%.2f", dna.getGCContent())).append("%\n");
                sb.append("• Reverse Complement: ").append(dna.getReverseComplement().substring(0, Math.min(30, dna.length()))).append("...\n");
                sb.append("• RNA Transcription: ").append(dna.transcribeToRNA().substring(0, Math.min(30, dna.length()))).append("...\n\n");

                sb.append("PHENOTYPE PREDICTIONS\n");
                sb.append("• Blood Type: ").append(dna.predictBloodType()).append("\n");
                sb.append("• Eye Color: ").append(dna.predictEyeColor()).append("\n");

                // Add ancestry analysis
                Analyzer.AncestryReport ancestryReport = Analyzer.analyzeAncestry(dna);
                sb.append("• Ancestry: ").append(ancestryReport.closestMatch).append(" (");
                sb.append(String.format("%.1f", ancestryReport.confidence)).append("% confidence)\n\n");

                sb.append("STR PROFILE\n");
                Map<String, Integer> strProfile = dna.getSTRProfile();
                int count = 0;
                for (Map.Entry<String, Integer> entry : strProfile.entrySet()) {
                    if (count++ >= 5) break;
                    sb.append("• ").append(entry.getKey()).append(": ").append(entry.getValue()).append(" repeats\n");
                }

                resultsArea.setText(sb.toString());

            } catch (Exception ex) {
                showAlert("Error", "Invalid DNA sequence", Alert.AlertType.ERROR);
            }
        });

        sampleBtn.setOnAction(e -> {
            dnaInput.setText("ATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG");
        });

        clearBtn.setOnAction(e -> {
            dnaInput.clear();
            resultsArea.clear();
        });

        leftColumn.getChildren().add(inputCard);
        rightColumn.getChildren().add(resultsCard);

        mainContent.getChildren().addAll(leftColumn, rightColumn);

        content.getChildren().addAll(header, mainContent);

        return createScrollPane(content);
    }

    // ========== ANCESTRY TAB ==========
    private ScrollPane createAncestryTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background-color: " + BACKGROUND + ";");

        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        VBox titleBox = new VBox(3);
        Label title = new Label("🌍 Ancestry Analysis");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        Label subtitle = new Label("Discover your genetic heritage using SNP markers");
        subtitle.setFont(Font.font("Segoe UI", SMALL_SIZE));
        subtitle.setTextFill(Color.web(TEXT_SECONDARY));
        titleBox.getChildren().addAll(title, subtitle);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().addAll(titleBox, spacer);

        HBox mainContent = new HBox(20);
        mainContent.setAlignment(Pos.TOP_LEFT);

        VBox leftColumn = new VBox(15);
        leftColumn.setPrefWidth(SCREEN_WIDTH * 0.4);

        VBox inputCard = createCard("📋 SNP Data Input");

        TableView<SNPEntry> snpTable = new TableView<>();
        snpTable.setPrefHeight(200);
        snpTable.setStyle("-fx-background-color: white; -fx-border-color: " + BORDER + "; -fx-border-radius: 6;");

        TableColumn<SNPEntry, String> rsidCol = new TableColumn<>("SNP ID");
        rsidCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().rsid));
        rsidCol.setPrefWidth(120);

        TableColumn<SNPEntry, String> allele1Col = new TableColumn<>("Allele 1");
        allele1Col.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().allele1)));
        allele1Col.setPrefWidth(80);

        TableColumn<SNPEntry, String> allele2Col = new TableColumn<>("Allele 2");
        allele2Col.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().allele2)));
        allele2Col.setPrefWidth(80);

        snpTable.getColumns().addAll(rsidCol, allele1Col, allele2Col);

        HBox buttonBox = new HBox(10);
        Button addBtn = createSmallButton("+ Add SNP", ACCENT);
        Button removeBtn = createSmallButton("− Remove", DANGER);
        Button sampleBtn = createSmallButton("Load Sample", SECONDARY);

        buttonBox.getChildren().addAll(addBtn, removeBtn, sampleBtn);

        Label manualLabel = new Label("Or input DNA sequence for auto-extraction:");
        manualLabel.setFont(Font.font("Segoe UI", BODY_SIZE));

        TextArea dnaInput = createTextArea("Enter full DNA sequence here...", 3);

        Button analyzeBtn = createModernButton("🌍 Analyze Ancestry", PRIMARY);
        analyzeBtn.setMaxWidth(Double.MAX_VALUE);

        inputCard.getChildren().addAll(
                new Label("Enter your SNP genotypes:"),
                snpTable,
                buttonBox,
                new Separator(),
                manualLabel,
                dnaInput,
                analyzeBtn
        );

        VBox rightColumn = new VBox(15);
        rightColumn.setPrefWidth(SCREEN_WIDTH * 0.4);

        VBox resultsCard = createCard("🧬 Ancestry Results");

        PieChart ancestryChart = new PieChart();
        ancestryChart.setPrefHeight(200);
        ancestryChart.setStyle("-fx-background-color: transparent;");
        ancestryChart.setLabelsVisible(true);

        TextArea resultsArea = createTextArea("Results will appear here...", 8);
        resultsArea.setEditable(false);

        VBox statsBox = new VBox(5);
        statsBox.setPadding(new Insets(10));
        statsBox.setStyle("-fx-background-color: #F8F9FA; -fx-border-color: " + BORDER + "; -fx-border-radius: 6;");

        Label closestLabel = new Label("Closest Match: --");
        Label confidenceLabel = new Label("Confidence: --");
        Label snpsLabel = new Label("SNPs Analyzed: --");

        closestLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, BODY_SIZE));
        confidenceLabel.setFont(Font.font("Segoe UI", BODY_SIZE));
        snpsLabel.setFont(Font.font("Segoe UI", BODY_SIZE));

        statsBox.getChildren().addAll(closestLabel, confidenceLabel, snpsLabel);

        resultsCard.getChildren().addAll(
                new Label("Ancestry Breakdown:"),
                ancestryChart,
                new Separator(),
                resultsArea,
                statsBox
        );

        sampleBtn.setOnAction(e -> {
            snpTable.getItems().clear();
            snpTable.getItems().addAll(
                    new SNPEntry("rs1426654", 'A', 'A'),
                    new SNPEntry("rs4988235", 'T', 'T'),
                    new SNPEntry("rs2814778", 'C', 'C'),
                    new SNPEntry("rs12913832", 'G', 'G'),
                    new SNPEntry("rs12203592", 'C', 'T')
            );
        });

        addBtn.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Add SNP");
            dialog.setHeaderText("Enter SNP Data");
            dialog.setContentText("Format: rsID allele1 allele2\nExample: rs1426654 A A");

            dialog.showAndWait().ifPresent(input -> {
                String[] parts = input.split("\\s+");
                if (parts.length == 3) {
                    snpTable.getItems().add(new SNPEntry(
                            parts[0],
                            parts[1].charAt(0),
                            parts[2].charAt(0)
                    ));
                }
            });
        });

        removeBtn.setOnAction(e -> {
            SNPEntry selected = snpTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                snpTable.getItems().remove(selected);
            }
        });

        analyzeBtn.setOnAction(e -> {
            try {
                AncestryDNA ancestryDNA = new AncestryDNA("User");

                for (SNPEntry entry : snpTable.getItems()) {
                    ancestryDNA.addSNP(entry.rsid, entry.allele1, entry.allele2);
                }

                if (!dnaInput.getText().trim().isEmpty()) {
                    DNASequence dna = new DNASequence(dnaInput.getText());
                    AncestryDNA extracted = dna.extractAncestryProfile();
                    for (Map.Entry<String, char[]> snp : extracted.getSnpProfile().entrySet()) {
                        char[] alleles = snp.getValue();
                        ancestryDNA.addSNP(snp.getKey(), alleles[0], alleles[1]);
                    }
                }

                Analyzer.AncestryReport result = Analyzer.analyzeAncestry(ancestryDNA);

                resultsArea.setText(result.formattedResults);

                ancestryChart.getData().clear();
                for (Map.Entry<String, Double> entry : result.composition.entrySet()) {
                    if (entry.getValue() > 1.0) {
                        PieChart.Data slice = new PieChart.Data(
                                entry.getKey() + " (" + String.format("%.1f", entry.getValue()) + "%)",
                                entry.getValue()
                        );
                        ancestryChart.getData().add(slice);
                    }
                }

                closestLabel.setText("Closest Match: " + result.closestMatch);
                confidenceLabel.setText(String.format("Confidence: %.1f%%", result.confidence));
                snpsLabel.setText("SNPs Analyzed: " + result.snpsAnalyzed);

            } catch (Exception ex) {
                showAlert("Error", "Invalid input: " + ex.getMessage(), Alert.AlertType.ERROR);
            }
        });

        leftColumn.getChildren().add(inputCard);
        rightColumn.getChildren().add(resultsCard);
        mainContent.getChildren().addAll(leftColumn, rightColumn);
        content.getChildren().addAll(header, mainContent);

        return createScrollPane(content);
    }

    // Helper class for SNP table
    private static class SNPEntry {
        String rsid;
        char allele1;
        char allele2;

        SNPEntry(String rsid, char allele1, char allele2) {
            this.rsid = rsid;
            this.allele1 = allele1;
            this.allele2 = allele2;
        }
    }

    // ========== PATERNITY TAB ==========
    private ScrollPane createPaternityTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("Paternity Test");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        // Family input in columns
        GridPane familyGrid = new GridPane();
        familyGrid.setHgap(15);
        familyGrid.setVgap(10);
        familyGrid.setPadding(new Insets(15));
        familyGrid.setStyle("-fx-background-color: " + CARD_BG + "; -fx-background-radius: 10;");

        TextArea fatherDNA = createCompactTextArea("Father's DNA", 3);
        TextArea motherDNA = createCompactTextArea("Mother's DNA", 3);
        TextArea childDNA = createCompactTextArea("Child's DNA", 3);

        familyGrid.add(createLabel("👨 Father:"), 0, 0);
        familyGrid.add(fatherDNA, 1, 0);
        familyGrid.add(createLabel("👩 Mother:"), 0, 1);
        familyGrid.add(motherDNA, 1, 1);
        familyGrid.add(createLabel("👶 Child:"), 0, 2);
        familyGrid.add(childDNA, 1, 2);

        // Test button
        Button testBtn = createModernButton("🔍 Run Paternity Test", SECONDARY);
        testBtn.setMaxWidth(Double.MAX_VALUE);

        // Results area
        VBox resultsCard = createCard("Test Results");
        TextArea resultsArea = createTextArea("", 8);
        resultsArea.setEditable(false);
        resultsCard.getChildren().add(resultsArea);

        // Action
        testBtn.setOnAction(e -> {
            try {
                DNASequence fatherSeq = new DNASequence(fatherDNA.getText());
                DNASequence motherSeq = new DNASequence(motherDNA.getText());
                DNASequence childSeq = new DNASequence(childDNA.getText());

                Analyzer.PaternityResult result = Analyzer.analyzePaternity(childSeq, fatherSeq, motherSeq);

                StringBuilder sb = new StringBuilder();
                sb.append("═ PATERNITY TEST RESULTS ════════════\n\n");
                sb.append("• Probability: ").append(String.format("%.2f", result.probability * 100)).append("%\n");
                sb.append("• Match Percentage: ").append(String.format("%.1f", result.matchPercentage)).append("%\n");
                sb.append("• Paternity Index: ").append(String.format("%.2f", result.paternityIndex)).append("\n");
                sb.append("• Matching Alleles: ").append(result.matchingAlleles).append("/").append(result.totalComparisons).append("\n\n");

                if (!result.mismatches.isEmpty()) {
                    sb.append("Mismatches Found:\n");
                    for (String mismatch : result.mismatches) {
                        sb.append("• ").append(mismatch).append("\n");
                    }
                    sb.append("\n");
                }

                sb.append(result.getConclusion());

                resultsArea.setText(sb.toString());

            } catch (Exception ex) {
                showAlert("Error", "Invalid DNA sequences", Alert.AlertType.ERROR);
            }
        });

        content.getChildren().addAll(title, familyGrid, testBtn, resultsCard);
        return createScrollPane(content);
    }

    // ========== DISEASE TAB ==========
    private ScrollPane createDiseaseTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("Disease Risk Analysis");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        // Input section
        VBox inputCard = createCard("DNA Input");
        TextArea dnaInput = createTextArea("Enter DNA for analysis...", 4);
        Button analyzeBtn = createModernButton("⚕️ Analyze Risk", WARNING);

        inputCard.getChildren().addAll(dnaInput, analyzeBtn);

        // Results and chart side by side
        HBox resultsRow = new HBox(15);

        VBox resultsCard = createCard("Risk Assessment");
        TextArea resultsArea = createTextArea("", 10);
        resultsArea.setEditable(false);
        resultsCard.getChildren().add(resultsArea);

        VBox chartCard = createCard("Risk Distribution");
        BarChart<String, Number> riskChart = createCompactBarChart();
        riskChart.setPrefSize(300, 200);
        chartCard.getChildren().add(riskChart);

        resultsRow.getChildren().addAll(resultsCard, chartCard);

        // Action
        analyzeBtn.setOnAction(e -> {
            try {
                DNASequence dna = new DNASequence(dnaInput.getText());
                Analyzer.DiseaseRisk risk = Analyzer.analyzeDiseaseRisk(dna);

                StringBuilder sb = new StringBuilder();
                sb.append("═ DISEASE RISK ASSESSMENT ══════════\n\n");
                sb.append("Risk Level: ").append(risk.getRiskLevel()).append("\n");
                sb.append("Risk Score: ").append(String.format("%.1f", risk.riskScore)).append("/100\n\n");

                if (!risk.detectedDiseases.isEmpty()) {
                    sb.append("⚠️ DETECTED RISKS:\n");
                    for (String disease : risk.detectedDiseases) {
                        sb.append("• ").append(disease).append("\n");
                    }
                    sb.append("\n");
                }

                if (!risk.carrierStatus.isEmpty()) {
                    sb.append("🧬 CARRIER STATUS:\n");
                    for (String carrier : risk.carrierStatus) {
                        sb.append("• ").append(carrier).append("\n");
                    }
                    sb.append("\n");
                }

                if (!risk.recommendations.isEmpty()) {
                    sb.append("💡 RECOMMENDATIONS:\n");
                    for (String rec : risk.recommendations) {
                        sb.append("• ").append(rec).append("\n");
                    }
                }

                resultsArea.setText(sb.toString());

                // Update chart
                riskChart.getData().clear();
                XYChart.Series<String, Number> series = new XYChart.Series<>();

                String[] diseases = {"HUNTINGTON", "SICKLE_CELL", "CYSTIC_FIBROSIS", "BRCA1"};
                for (String disease : diseases) {
                    if (dna.hasDiseaseMarker(disease)) {
                        series.getData().add(new XYChart.Data<>(disease.substring(0, Math.min(10, disease.length())), 75));
                    } else {
                        series.getData().add(new XYChart.Data<>(disease.substring(0, Math.min(10, disease.length())), 5));
                    }
                }

                riskChart.getData().add(series);

            } catch (Exception ex) {
                showAlert("Error", "Invalid DNA sequence", Alert.AlertType.ERROR);
            }
        });

        content.getChildren().addAll(title, inputCard, resultsRow);
        return createScrollPane(content);
    }

    // ========== FORENSIC TAB ==========
    private ScrollPane createForensicTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("Forensic DNA Analysis");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        // Two column input
        HBox inputRow = new HBox(15);

        VBox crimeCard = createCard("🕵️ Crime Scene DNA");
        TextArea crimeDNA = createTextArea("Crime scene sample...", 3);
        crimeCard.getChildren().add(crimeDNA);

        VBox suspectCard = createCard("👤 Suspect DNA");
        TextArea suspectDNA = createTextArea("Suspect sample...", 3);
        suspectCard.getChildren().add(suspectDNA);

        inputRow.getChildren().addAll(crimeCard, suspectCard);

        Button compareBtn = createModernButton("🔍 Compare DNA", DANGER);
        compareBtn.setMaxWidth(Double.MAX_VALUE);

        // Results
        VBox resultsCard = createCard("Forensic Match Results");
        TextArea resultsArea = createTextArea("", 10);
        resultsArea.setEditable(false);
        resultsCard.getChildren().add(resultsArea);

        // Action
        compareBtn.setOnAction(e -> {
            try {
                DNASequence crimeSeq = new DNASequence(crimeDNA.getText());
                DNASequence suspectSeq = new DNASequence(suspectDNA.getText());

                Analyzer.ForensicMatch match = Analyzer.compareDNA(crimeSeq, suspectSeq);

                StringBuilder sb = new StringBuilder();
                sb.append("═ FORENSIC DNA ANALYSIS ════════════\n\n");
                sb.append("• Sequence Similarity: ").append(String.format("%.2f", match.sequenceSimilarity)).append("%\n");
                sb.append("• STR Match: ").append(String.format("%.2f", match.strMatchPercentage)).append("%\n");
                sb.append("• STR Loci Matched: ").append(match.strMatches).append("/").append(match.totalSTRs).append("\n");
                sb.append("• Random Match Probability: ").append(String.format("%.2e", match.randomMatchProbability)).append("\n\n");
                sb.append("Interpretation: ").append(match.interpretation);

                resultsArea.setText(sb.toString());

            } catch (Exception ex) {
                showAlert("Error", "Invalid DNA sequences", Alert.AlertType.ERROR);
            }
        });

        content.getChildren().addAll(title, inputRow, compareBtn, resultsCard);
        return createScrollPane(content);
    }

    // ========== PHARMACOGENOMICS TAB ==========
    private ScrollPane createPharmacoTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("Pharmacogenomics");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        VBox inputCard = createCard("DNA for Drug Response");
        TextArea dnaInput = createTextArea("Enter DNA...", 3);
        Button analyzeBtn = createModernButton("💊 Analyze Responses", SUCCESS);

        inputCard.getChildren().addAll(dnaInput, analyzeBtn);

        // Results in a table
        VBox resultsCard = createCard("Drug Response Profile");
        TableView<Analyzer.DrugResponse> table = createCompactTable();
        resultsCard.getChildren().add(table);

        // Action
        analyzeBtn.setOnAction(e -> {
            try {
                DNASequence dna = new DNASequence(dnaInput.getText());
                List<Analyzer.DrugResponse> responses = Analyzer.analyzeDrugResponses(dna);

                table.getItems().clear();
                for (Analyzer.DrugResponse resp : responses) {
                    table.getItems().add(resp);
                }

            } catch (Exception ex) {
                showAlert("Error", "Invalid DNA sequence", Alert.AlertType.ERROR);
            }
        });

        content.getChildren().addAll(title, inputCard, resultsCard);
        return createScrollPane(content);
    }

    // ========== DATABASE TAB ==========
    private ScrollPane createDatabaseTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("DNA Database");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        // Add form and list side by side
        HBox mainRow = new HBox(15);

        // Left - Add form
        VBox formCard = createCard("Add New Profile");
        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.setPadding(new Insets(15));

        TextField nameField = createTextField("Full Name");
        ComboBox<Person.Sex> sexCombo = new ComboBox<>();
        sexCombo.getItems().addAll(Person.Sex.values());
        sexCombo.setValue(Person.Sex.UNKNOWN);
        sexCombo.setStyle("-fx-background-color: white; -fx-border-color: " + BORDER + "; -fx-border-radius: 5;");

        TextField ageField = createTextField("Age");
        TextArea dnaField = createTextArea("DNA Sequence", 2);

        formGrid.add(createLabel("Name:"), 0, 0);
        formGrid.add(nameField, 1, 0);
        formGrid.add(createLabel("Sex:"), 0, 1);
        formGrid.add(sexCombo, 1, 1);
        formGrid.add(createLabel("Age:"), 0, 2);
        formGrid.add(ageField, 1, 2);
        formGrid.add(createLabel("DNA:"), 0, 3);
        formGrid.add(dnaField, 1, 3);

        Button addBtn = createModernButton("➕ Add to Database", SUCCESS);
        addBtn.setMaxWidth(Double.MAX_VALUE);

        formCard.getChildren().addAll(formGrid, addBtn);

        // Right - Database list
        VBox listCard = createCard("Stored Profiles (" + personDatabase.size() + ")");
        ListView<Person> listView = new ListView<>();
        listView.setPrefHeight(300);
        listView.setCellFactory(lv -> new ListCell<Person>() {
            @Override
            protected void updateItem(Person person, boolean empty) {
                super.updateItem(person, empty);
                if (empty || person == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    HBox cell = new HBox(10);
                    cell.setAlignment(Pos.CENTER_LEFT);

                    Label icon = new Label(person.getSex() == Person.Sex.MALE ? "👨" :
                            person.getSex() == Person.Sex.FEMALE ? "👩" : "👤");

                    VBox info = new VBox(2);
                    Label name = new Label(person.getName());
                    name.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, BODY_SIZE));

                    Label details = new Label(person.getAge() + " years • " +
                            person.getDnaSequence().length() + " bp");
                    details.setFont(Font.font("Segoe UI", SMALL_SIZE));
                    details.setTextFill(Color.web(TEXT_SECONDARY));

                    info.getChildren().addAll(name, details);
                    cell.getChildren().addAll(icon, info);
                    setGraphic(cell);
                }
            }
        });

        listCard.getChildren().add(listView);

        // Add button action
        addBtn.setOnAction(e -> {
            try {
                Person person = new Person(
                        "ID-" + (personDatabase.size() + 1000),
                        nameField.getText(),
                        sexCombo.getValue(),
                        LocalDate.now().minusYears(Integer.parseInt(ageField.getText())),
                        new DNASequence(dnaField.getText())
                );

                personDatabase.add(person);
                listView.getItems().add(person);

                // Update card title
                ((Label)((VBox)listCard.getChildren().get(0)).getChildren().get(0))
                        .setText("Stored Profiles (" + personDatabase.size() + ")");

                // Clear form
                nameField.clear();
                ageField.clear();
                dnaField.clear();

            } catch (Exception ex) {
                showAlert("Error", "Invalid data", Alert.AlertType.ERROR);
            }
        });

        mainRow.getChildren().addAll(formCard, listCard);
        content.getChildren().addAll(title, mainRow);
        return createScrollPane(content);
    }

    // ========== REPORTS TAB ==========
    private ScrollPane createReportsTab() {
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));

        Label title = new Label("Report Generation");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, TITLE_SIZE));
        title.setTextFill(Color.web(TEXT_PRIMARY));

        VBox reportCard = createCard("Generate and Print Reports");

        ComboBox<String> reportType = new ComboBox<>();
        reportType.getItems().addAll("DNA Analysis", "Paternity Test", "Disease Risk", "Forensic", "Custom");
        reportType.setValue("DNA Analysis");
        reportType.setStyle("-fx-background-color: white; -fx-border-color: " + BORDER + "; -fx-border-radius: 5;");

        TextArea preview = createTextArea("Report preview will appear here...", 10);
        preview.setEditable(false);

        HBox buttonRow = new HBox(10);
        Button generateBtn = createModernButton("📄 Generate", SECONDARY);
        Button printBtn = createModernButton("🖨️ Print", PRIMARY);
        Button saveBtn = createModernButton("💾 Save PDF", SUCCESS);

        buttonRow.getChildren().addAll(generateBtn, printBtn, saveBtn);

        reportCard.getChildren().addAll(
                new Label("Report Type:"),
                reportType,
                preview,
                buttonRow
        );

        content.getChildren().addAll(title, reportCard);
        return createScrollPane(content);
    }

    // ========== HELPER METHODS ==========
    private VBox createCard(String title) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: " + CARD_BG + "; " +
                "-fx-background-radius: 10; " +
                "-fx-border-color: " + BORDER + "; " +
                "-fx-border-radius: 10; " +
                "-fx-border-width: 1; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0.2, 0, 2);");

        if (title != null) {
            Label titleLabel = new Label(title);
            titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, SUBTITLE_SIZE));
            titleLabel.setTextFill(Color.web(TEXT_PRIMARY));
            card.getChildren().add(titleLabel);
        }

        return card;
    }

    private TextArea createTextArea(String prompt, int rows) {
        TextArea area = new TextArea();
        area.setPromptText(prompt);
        area.setPrefRowCount(rows);
        area.setStyle("-fx-font-family: 'Segoe UI'; " +
                "-fx-font-size: " + BODY_SIZE + "px; " +
                "-fx-background-color: white; " +
                "-fx-text-fill: " + TEXT_PRIMARY + "; " +
                "-fx-border-color: " + BORDER + "; " +
                "-fx-border-radius: 6; " +
                "-fx-padding: 8;");
        return area;
    }

    private TextArea createCompactTextArea(String prompt, int rows) {
        TextArea area = createTextArea(prompt, rows);
        area.setPrefRowCount(rows);
        area.setPrefHeight(rows * 20);
        return area;
    }

    private TextField createTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setStyle("-fx-font-family: 'Segoe UI'; " +
                "-fx-font-size: " + BODY_SIZE + "px; " +
                "-fx-background-color: white; " +
                "-fx-text-fill: " + TEXT_PRIMARY + "; " +
                "-fx-border-color: " + BORDER + "; " +
                "-fx-border-radius: 6; " +
                "-fx-padding: 8 10;");
        return field;
    }

    private Button createModernButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, BODY_SIZE));
        button.setTextFill(Color.WHITE);
        button.setPadding(new Insets(8, 15, 8, 15));
        button.setStyle("-fx-background-color: " + color + "; " +
                "-fx-background-radius: 6; " +
                "-fx-cursor: hand; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 3, 0.3, 0, 1);");

        button.setOnMouseEntered(e -> button.setStyle(
                "-fx-background-color: derive(" + color + ", 20%); " +
                        "-fx-background-radius: 6; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 4, 0.4, 0, 2);"));

        button.setOnMouseExited(e -> button.setStyle(
                "-fx-background-color: " + color + "; " +
                        "-fx-background-radius: 6; " +
                        "-fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 3, 0.3, 0, 1);"));

        return button;
    }

    private Button createFlatButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", BODY_SIZE));
        button.setTextFill(Color.WHITE);
        button.setStyle("-fx-background-color: transparent; -fx-border-color: " + color + "; -fx-border-width: 1; " +
                "-fx-border-radius: 4; -fx-cursor: hand;");
        return button;
    }

    private Button createSmallButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", SMALL_SIZE));
        button.setTextFill(Color.WHITE);
        button.setPadding(new Insets(5, 10, 5, 10));
        button.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 4; -fx-cursor: hand;");
        return button;
    }

    private Label createLabel(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Segoe UI", BODY_SIZE));
        label.setTextFill(Color.web(TEXT_PRIMARY));
        return label;
    }

    private PieChart createCompactPieChart() {
        PieChart chart = new PieChart();
        chart.setStyle("-fx-background-color: transparent;");
        chart.setLegendVisible(true);
        chart.setLabelsVisible(true);
        chart.setLabelLineLength(5);
        chart.setStartAngle(90);
        return chart;
    }

    private BarChart<String, Number> createCompactBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();

        xAxis.setTickLabelFont(Font.font("Segoe UI", SMALL_SIZE));
        yAxis.setTickLabelFont(Font.font("Segoe UI", SMALL_SIZE));

        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setStyle("-fx-background-color: transparent;");
        chart.setLegendVisible(false);
        chart.setAnimated(false);

        return chart;
    }

    private TableView<Analyzer.DrugResponse> createCompactTable() {
        TableView<Analyzer.DrugResponse> table = new TableView<>();
        table.setPrefHeight(250);

        TableColumn<Analyzer.DrugResponse, String> drugCol = new TableColumn<>("Drug");
        drugCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().drugName));
        drugCol.setPrefWidth(150);

        TableColumn<Analyzer.DrugResponse, String> responseCol = new TableColumn<>("Response");
        responseCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().response));
        responseCol.setPrefWidth(300);

        table.getColumns().addAll(drugCol, responseCol);
        table.setStyle("-fx-background-color: white; -fx-border-color: " + BORDER + "; -fx-border-radius: 6;");

        return table;
    }

    private ScrollPane createScrollPane(VBox content) {
        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        scrollPane.setPadding(new Insets(5));
        return scrollPane;
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);

        DialogPane dialog = alert.getDialogPane();
        dialog.setStyle("-fx-background-color: white; " +
                "-fx-font-family: 'Segoe UI'; " +
                "-fx-font-size: " + BODY_SIZE + "px; " +
                "-fx-border-color: " + BORDER + "; " +
                "-fx-border-radius: 8;");

        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}