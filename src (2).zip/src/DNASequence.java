import java.util.*;

public class DNASequence {
    private String sequence;
    private Map<String, Integer> strProfile;

    public DNASequence(String sequence) {
        this.sequence = validateAndClean(sequence);
        this.strProfile = new HashMap<>();
        calculateSTRProfile();
    }

    private String validateAndClean(String seq) {
        if (seq == null || seq.trim().isEmpty()) {
            return "";
        }
        String cleaned = seq.toUpperCase().replaceAll("[^ACGT]", "");
        if (cleaned.length() > 10000) {
            cleaned = cleaned.substring(0, 10000);
        }
        return cleaned;
    }

    // ========== BASIC DNA PROPERTIES ==========
    public String getSequence() { return sequence; }
    public int length() { return sequence.length(); }

    public double getGCContent() {
        if (sequence.isEmpty()) return 0.0;
        long gcCount = sequence.chars().filter(c -> c == 'G' || c == 'C').count();
        return (gcCount * 100.0) / sequence.length();
    }

    public String getReverseComplement() {
        StringBuilder rc = new StringBuilder();
        for (int i = sequence.length() - 1; i >= 0; i--) {
            char c = sequence.charAt(i);
            switch (c) {
                case 'A': rc.append('T'); break;
                case 'T': rc.append('A'); break;
                case 'C': rc.append('G'); break;
                case 'G': rc.append('C'); break;
                default: rc.append('N');
            }
        }
        return rc.toString();
    }

    public String transcribeToRNA() {
        return sequence.replace('T', 'U');
    }

    // ========== STR ANALYSIS ==========
    private void calculateSTRProfile() {
        String[] strMarkers = {"D3S1358", "TH01", "D21S11", "D18S51", "FGA",
                "D5S818", "D13S317", "D7S820", "D16S539", "CSF1PO"};
        String[] patterns = {"AGAT", "AATG", "TATC", "AGAA", "CTTT",
                "AGAT", "TATC", "GATA", "GATA", "AGAT"};

        for (int i = 0; i < strMarkers.length; i++) {
            int repeats = countSTRRepeats(patterns[i]);
            strProfile.put(strMarkers[i], repeats);
        }
    }

    private int countSTRRepeats(String pattern) {
        if (pattern.isEmpty() || sequence.isEmpty()) return 0;
        int maxRepeats = 0;
        int currentRepeats = 0;
        int patternLen = pattern.length();

        for (int i = 0; i <= sequence.length() - patternLen; i++) {
            if (sequence.regionMatches(i, pattern, 0, patternLen)) {
                currentRepeats++;
                i += patternLen - 1;
                maxRepeats = Math.max(maxRepeats, currentRepeats);
            } else {
                currentRepeats = 0;
            }
        }
        return maxRepeats;
    }

    public Map<String, Integer> getSTRProfile() {
        return new HashMap<>(strProfile);
    }

    // ========== DISEASE MARKER DETECTION ==========
    public boolean hasDiseaseMarker(String disease) {
        switch (disease.toUpperCase()) {
            case "HUNTINGTON": return countSTRRepeats("CAG") > 35;
            case "SICKLE_CELL": return sequence.contains("GTG") && countSTRRepeats("GTG") > 2;
            case "CYSTIC_FIBROSIS": return sequence.contains("CTTT") && sequence.contains("GGTA");
            case "BRCA1": return sequence.contains("GCAT") && sequence.contains("TACG");
            default: return false;
        }
    }

    // ========== PHENOTYPE PREDICTION ==========
    public String predictBloodType() {
        if (sequence.contains("AAG") && sequence.contains("TTC")) {
            return "A";
        } else if (sequence.contains("GGT") && sequence.contains("CCA")) {
            return "B";
        } else if (sequence.contains("AAG") && sequence.contains("GGT")) {
            return "AB";
        } else {
            return "O";
        }
    }

    public String predictEyeColor() {
        int brownMarkers = 0;
        int blueMarkers = 0;

        if (sequence.contains("GATC")) brownMarkers++;
        if (sequence.contains("CTAG")) brownMarkers++;
        if (sequence.contains("ATCG")) blueMarkers++;
        if (sequence.contains("TCGA")) blueMarkers++;

        if (brownMarkers > blueMarkers) return "Brown";
        if (blueMarkers > brownMarkers) return "Blue";
        return "Green/Hazel";
    }

    // ========== ANCESTRY PREDICTION ==========
    public String predictAncestry() {
        return Analyzer.getSimpleAncestry(this);
    }

    public AncestryDNA extractAncestryProfile() {
        return new AncestryDNA("DNA Sample", this);
    }

    // ========== DRUG RESPONSE ==========
    public String getWarfarinResponse() {
        if (sequence.contains("CYP2C9")) {
            return "Slow metabolizer - lower dose needed";
        } else if (sequence.contains("VKORC1")) {
            return "Sensitive - lower dose needed";
        } else {
            return "Normal response - standard dose";
        }
    }

    public String getClopidogrelResponse() {
        if (sequence.contains("CYP2C19")) {
            return "Poor metabolizer - alternative drug recommended";
        } else {
            return "Normal response - standard dose";
        }
    }

    // ========== FORENSIC METHODS ==========
    public double calculateRandomMatchProbability() {
        double rmp = 1.0;
        for (int repeats : strProfile.values()) {
            double freq = getSTRFrequency(repeats);
            rmp *= freq;
        }
        return rmp;
    }

    private double getSTRFrequency(int repeats) {
        if (repeats < 5) return 0.01;
        if (repeats < 10) return 0.05;
        if (repeats < 15) return 0.1;
        if (repeats < 20) return 0.05;
        return 0.01;
    }

    // ========== COMPARISON METHODS ==========
    public double compareTo(DNASequence other) {
        if (sequence.isEmpty() || other.sequence.isEmpty()) return 0.0;
        int minLength = Math.min(sequence.length(), other.sequence.length());
        int matches = 0;

        for (int i = 0; i < minLength; i++) {
            if (sequence.charAt(i) == other.sequence.charAt(i)) {
                matches++;
            }
        }
        return (matches * 100.0) / minLength;
    }

    // Helper method for pattern counting
    private int countPattern(String pattern) {
        int count = 0;
        for (int i = 0; i <= sequence.length() - pattern.length(); i++) {
            if (sequence.substring(i, i + pattern.length()).equals(pattern)) {
                count++;
            }
        }
        return count;
    }

    @Override
    public String toString() {
        return String.format("""
            DNA Sequence Analysis:
            Length: %d bp
            GC Content: %.1f%%
            Blood Type: %s
            Eye Color: %s
            Ancestry: %s
            STR Profile: %d markers
            """,
                length(), getGCContent(), predictBloodType(),
                predictEyeColor(), predictAncestry(), strProfile.size());
    }
}