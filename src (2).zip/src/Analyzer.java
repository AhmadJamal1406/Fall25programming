import java.util.*;

public class Analyzer {
    // ========== PATERNITY ANALYSIS ==========
    public static PaternityResult analyzePaternity(DNASequence child,
                                                   DNASequence allegedFather,
                                                   DNASequence mother) {
        Map<String, Integer> childSTR = child.getSTRProfile();
        Map<String, Integer> fatherSTR = allegedFather.getSTRProfile();
        Map<String, Integer> motherSTR = mother.getSTRProfile();

        int matchingAlleles = 0;
        int totalComparisons = 0;
        List<String> mismatches = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : childSTR.entrySet()) {
            String locus = entry.getKey();
            int childAllele = entry.getValue();
            Integer fatherAllele = fatherSTR.get(locus);
            Integer motherAllele = motherSTR.get(locus);

            if (fatherAllele != null && motherAllele != null) {
                totalComparisons++;
                if (childAllele == fatherAllele || childAllele == motherAllele) {
                    matchingAlleles++;
                } else {
                    mismatches.add(locus);
                }
            }
        }

        double matchPercentage = (totalComparisons > 0) ?
                (matchingAlleles * 100.0) / totalComparisons : 0.0;

        double paternityIndex = calculatePaternityIndex(matchPercentage);
        double probability = calculateProbability(paternityIndex);

        return new PaternityResult(matchPercentage, paternityIndex, probability,
                matchingAlleles, totalComparisons, mismatches);
    }

    private static double calculatePaternityIndex(double matchPercentage) {
        if (matchPercentage > 99) return 10000;
        if (matchPercentage > 95) return 1000;
        if (matchPercentage > 90) return 100;
        if (matchPercentage > 80) return 10;
        return 1;
    }

    private static double calculateProbability(double paternityIndex) {
        return (paternityIndex * 0.5) / ((paternityIndex * 0.5) + 0.5);
    }

    // ========== FORENSIC ANALYSIS ==========
    public static ForensicMatch compareDNA(DNASequence crimeScene, DNASequence suspect) {
        double similarity = crimeScene.compareTo(suspect);
        Map<String, Integer> crimeSTR = crimeScene.getSTRProfile();
        Map<String, Integer> suspectSTR = suspect.getSTRProfile();

        int strMatches = 0;
        int totalSTRs = 0;
        List<String> matchingLoci = new ArrayList<>();
        List<String> differentLoci = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : crimeSTR.entrySet()) {
            String locus = entry.getKey();
            Integer crimeAllele = entry.getValue();
            Integer suspectAllele = suspectSTR.get(locus);

            if (suspectAllele != null) {
                totalSTRs++;
                if (crimeAllele.equals(suspectAllele)) {
                    strMatches++;
                    matchingLoci.add(locus + " (" + crimeAllele + ")");
                } else {
                    differentLoci.add(locus + ": Crime=" + crimeAllele + ", Suspect=" + suspectAllele);
                }
            }
        }

        double strMatchPercentage = (totalSTRs > 0) ?
                (strMatches * 100.0) / totalSTRs : 0.0;

        double rmp = crimeScene.calculateRandomMatchProbability();
        String interpretation = interpretForensicMatch(strMatchPercentage, rmp);

        return new ForensicMatch(similarity, strMatchPercentage, strMatches,
                totalSTRs, rmp, interpretation, matchingLoci, differentLoci);
    }

    private static String interpretForensicMatch(double strMatchPercentage, double rmp) {
        if (strMatchPercentage == 100 && rmp < 1e-9) {
            return "Very Strong Evidence: Profiles match at all loci, random match probability < 1 in 1 billion";
        } else if (strMatchPercentage > 95 && rmp < 1e-6) {
            return "Strong Evidence: High match percentage, random match probability < 1 in 1 million";
        } else if (strMatchPercentage > 80 && rmp < 1e-3) {
            return "Moderate Evidence: Profiles show significant similarity";
        } else if (strMatchPercentage > 50) {
            return "Weak Evidence: Some similarity, but not conclusive";
        } else {
            return "No Match: Profiles are different";
        }
    }

    // ========== DISEASE RISK ANALYSIS ==========
    public static DiseaseRisk analyzeDiseaseRisk(DNASequence dna) {
        List<String> detectedDiseases = new ArrayList<>();
        List<String> carrierStatus = new ArrayList<>();
        List<String> recommendations = new ArrayList<>();

        if (dna.hasDiseaseMarker("HUNTINGTON")) {
            detectedDiseases.add("Huntington's Disease - High risk (>35 CAG repeats)");
            recommendations.add("Genetic counseling recommended");
        }

        if (dna.hasDiseaseMarker("SICKLE_CELL")) {
            detectedDiseases.add("Sickle Cell Trait/Carrier");
            carrierStatus.add("Carrier for sickle cell anemia");
        }

        if (dna.hasDiseaseMarker("CYSTIC_FIBROSIS")) {
            carrierStatus.add("Possible cystic fibrosis carrier");
            recommendations.add("Consider carrier testing for partner");
        }

        if (dna.hasDiseaseMarker("BRCA1")) {
            detectedDiseases.add("Increased breast cancer risk (BRCA1 markers detected)");
            recommendations.add("Consider enhanced cancer screening");
        }

        double riskScore = calculateRiskScore(detectedDiseases.size(), carrierStatus.size());

        return new DiseaseRisk(detectedDiseases, carrierStatus, recommendations, riskScore);
    }

    private static double calculateRiskScore(int diseaseCount, int carrierCount) {
        return diseaseCount * 30 + carrierCount * 10;
    }

    // ========== PHARMACOGENOMICS ANALYSIS ==========
    public static List<DrugResponse> analyzeDrugResponses(DNASequence dna) {
        List<DrugResponse> responses = new ArrayList<>();

        responses.add(new DrugResponse("Warfarin", dna.getWarfarinResponse()));
        responses.add(new DrugResponse("Clopidogrel (Plavix)", dna.getClopidogrelResponse()));
        responses.add(new DrugResponse("Statins",
                dna.hasDiseaseMarker("BRCA1") ? "Increased muscle toxicity risk" : "Normal response"));
        responses.add(new DrugResponse("Codeine",
                dna.getSequence().contains("CYP2D6") ? "Ultra-rapid metabolizer - risk of overdose" : "Normal response"));

        return responses;
    }

    // ========== ANCESTRY ANALYSIS ==========
    public static AncestryReport analyzeAncestry(AncestryDNA dna) {
        AncestryAnalyzer analyzer = new AncestryAnalyzer();
        AncestryResult result = analyzer.analyze(dna);
        return new AncestryReport(result);
    }

    public static AncestryReport analyzeAncestry(DNASequence dna) {
        AncestryDNA ancestryDNA = new AncestryDNA("DNA Sample", dna);
        return analyzeAncestry(ancestryDNA);
    }

    public static String getSimpleAncestry(DNASequence dna) {
        AncestryAnalyzer analyzer = new AncestryAnalyzer();
        return analyzer.analyzeSimple(dna);
    }

    // ========== RESULT CLASSES ==========
    public static class PaternityResult {
        public final double matchPercentage;
        public final double paternityIndex;
        public final double probability;
        public final int matchingAlleles;
        public final int totalComparisons;
        public final List<String> mismatches;

        public PaternityResult(double matchPercentage, double paternityIndex, double probability,
                               int matchingAlleles, int totalComparisons, List<String> mismatches) {
            this.matchPercentage = matchPercentage;
            this.paternityIndex = paternityIndex;
            this.probability = probability;
            this.matchingAlleles = matchingAlleles;
            this.totalComparisons = totalComparisons;
            this.mismatches = mismatches;
        }

        public String getConclusion() {
            if (probability > 0.99) {
                return "CONCLUSION: The alleged father is VERY LIKELY the biological father (Probability > 99%).";
            } else if (probability > 0.95) {
                return "CONCLUSION: The alleged father is LIKELY the biological father.";
            } else if (probability > 0.80) {
                return "CONCLUSION: Paternity is POSSIBLE but not certain.";
            } else {
                return "CONCLUSION: The alleged father is EXCLUDED as the biological father.";
            }
        }
    }

    public static class ForensicMatch {
        public final double sequenceSimilarity;
        public final double strMatchPercentage;
        public final int strMatches;
        public final int totalSTRs;
        public final double randomMatchProbability;
        public final String interpretation;
        public final List<String> matchingLoci;
        public final List<String> differentLoci;

        public ForensicMatch(double similarity, double strMatchPercentage, int strMatches,
                             int totalSTRs, double rmp, String interpretation,
                             List<String> matchingLoci, List<String> differentLoci) {
            this.sequenceSimilarity = similarity;
            this.strMatchPercentage = strMatchPercentage;
            this.strMatches = strMatches;
            this.totalSTRs = totalSTRs;
            this.randomMatchProbability = rmp;
            this.interpretation = interpretation;
            this.matchingLoci = matchingLoci;
            this.differentLoci = differentLoci;
        }
    }

    public static class DiseaseRisk {
        public final List<String> detectedDiseases;
        public final List<String> carrierStatus;
        public final List<String> recommendations;
        public final double riskScore;

        public DiseaseRisk(List<String> detectedDiseases, List<String> carrierStatus,
                           List<String> recommendations, double riskScore) {
            this.detectedDiseases = detectedDiseases;
            this.carrierStatus = carrierStatus;
            this.recommendations = recommendations;
            this.riskScore = riskScore;
        }

        public String getRiskLevel() {
            if (riskScore > 60) return "High Risk";
            if (riskScore > 30) return "Moderate Risk";
            return "Low Risk";
        }
    }

    public static class DrugResponse {
        public final String drugName;
        public final String response;

        public DrugResponse(String drugName, String response) {
            this.drugName = drugName;
            this.response = response;
        }
    }

    public static class AncestryReport {
        public final Map<String, Double> composition;
        public final String closestMatch;
        public final double confidence;
        public final String formattedResults;
        public final int snpsAnalyzed;

        public AncestryReport(AncestryResult result) {
            this.composition = result.getAncestryComposition();
            this.closestMatch = result.getClosestMatch();
            this.confidence = result.getConfidence();
            this.formattedResults = result.getFormattedResults();
            this.snpsAnalyzed = result.getSnpsAnalyzed();
        }

        public String getSummary() {
            return String.format("Closest Match: %s (Confidence: %.1f%%)", closestMatch, confidence);
        }
    }
}