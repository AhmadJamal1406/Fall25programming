

import java.util.*;

    /**
     * Represents genetic data for a specific population
     */
    public class PopulationData {
        private final String populationName;
        private final Map<String, SNPData> snpData;

        public PopulationData(String populationName) {
            this.populationName = populationName;
            this.snpData = new HashMap<>();
        }

        public void addSNP(String rsid, char allele, double frequency) {
            snpData.put(rsid, new SNPData(rsid, allele, frequency));
        }

        public SNPData getSNP(String rsid) {
            return snpData.get(rsid);
        }

        public Set<String> getSNPIds() {
            return snpData.keySet();
        }

        public String getPopulationName() {
            return populationName;
        }

        @Override
        public String toString() {
            return populationName + " (SNPs: " + snpData.size() + ")";
        }

        /**
         * Inner class to store SNP data for a population
         */
        public static class SNPData {
            private final String rsid;
            private final char allele;
            private final double frequency;

            public SNPData(String rsid, char allele, double frequency) {
                this.rsid = rsid;
                this.allele = allele;
                this.frequency = frequency;
            }

            public String getRsid() { return rsid; }
            public char getAllele() { return allele; }
            public double getFrequency() { return frequency; }
        }
    }

