import java.util.*;

public class PopulationDatabase {
    private static PopulationDatabase instance;
    private final Map<String, Population> populations;

    private PopulationDatabase() {
        populations = new HashMap<>();
        loadReferenceData();
    }

    public static PopulationDatabase getInstance() {
        if (instance == null) {
            instance = new PopulationDatabase();
        }
        return instance;
    }

    private void loadReferenceData() {
        Population european = new Population("European", "Europe");
        european.addSNP("rs1426654", 'A', 0.95);
        european.addSNP("rs4988235", 'T', 0.75);
        european.addSNP("rs2814778", 'C', 0.03);
        european.addSNP("rs12913832", 'G', 0.90);
        european.addSNP("rs12203592", 'C', 0.80);
        populations.put("European", european);

        Population african = new Population("African", "Africa");
        african.addSNP("rs1426654", 'G', 0.95);
        african.addSNP("rs4988235", 'T', 0.05);
        african.addSNP("rs2814778", 'C', 0.95);
        african.addSNP("rs12913832", 'G', 0.10);
        african.addSNP("rs12203592", 'C', 0.10);
        populations.put("African", african);

        Population eastAsian = new Population("East Asian", "Asia");
        eastAsian.addSNP("rs1426654", 'A', 0.20);
        eastAsian.addSNP("rs4988235", 'T', 0.10);
        eastAsian.addSNP("rs2814778", 'C', 0.05);
        eastAsian.addSNP("rs12913832", 'G', 0.10);
        eastAsian.addSNP("rs12203592", 'C', 0.30);
        populations.put("East Asian", eastAsian);

        Population southAsian = new Population("South Asian", "South Asia");
        southAsian.addSNP("rs1426654", 'A', 0.50);
        southAsian.addSNP("rs4988235", 'T', 0.30);
        southAsian.addSNP("rs2814778", 'C', 0.10);
        southAsian.addSNP("rs12913832", 'G', 0.20);
        southAsian.addSNP("rs12203592", 'C', 0.40);
        populations.put("South Asian", southAsian);

        Population nativeAmerican = new Population("Native American", "Americas");
        nativeAmerican.addSNP("rs1426654", 'A', 0.35);
        nativeAmerican.addSNP("rs4988235", 'T', 0.05);
        nativeAmerican.addSNP("rs2814778", 'C', 0.02);
        nativeAmerican.addSNP("rs12913832", 'G', 0.15);
        nativeAmerican.addSNP("rs12203592", 'C', 0.25);
        populations.put("Native American", nativeAmerican);
    }

    public Population getPopulation(String name) {
        return populations.get(name);
    }

    public List<String> getAllPopulationNames() {
        return new ArrayList<>(populations.keySet());
    }

    public Set<String> getAllSNPIds() {
        Set<String> allSNPs = new HashSet<>();
        for (Population pop : populations.values()) {
            allSNPs.addAll(pop.getSNPIds());
        }
        return allSNPs;
    }

    public boolean validateSNP(String rsid, char allele) {
        for (Population pop : populations.values()) {
            if (pop.hasSNP(rsid) && pop.getCommonAllele(rsid) == allele) {
                return true;
            }
        }
        return false;
    }
}