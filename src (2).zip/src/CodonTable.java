public class CodonTable {

    public static String getAminoAcid(String codon) {
        if (codon == null || codon.length() != 3) return "Invalid";

        codon = codon.toUpperCase();

        switch (codon) {
            case "TTT": case "TTC": return "F";
            case "TTA": case "TTG": case "CTT": case "CTC": case "CTA": case "CTG": return "L";
            case "ATT": case "ATC": case "ATA": return "I";
            case "ATG": return "M";
            case "GTT": case "GTC": case "GTA": case "GTG": return "V";

            // Add other codons...

            default: return "Unknown";
        }
    }
}
