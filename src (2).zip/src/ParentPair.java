import java.util.*;

public class ParentPair {
    private Person father;
    private Person mother;

    public ParentPair(Person father, Person mother) {
        this.father = father;
        this.mother = mother;
    }

    public Person getFather() { return father; }
    public Person getMother() { return mother; }

    // ========== TRAIT PREDICTION FOR CHILDREN ==========

    public Map<String, String> predictChildTraits() {
        Map<String, String> predictions = new HashMap<>();

        DNASequence fatherDNA = father.getDnaSequence();
        DNASequence motherDNA = mother.getDnaSequence();

        // Blood type inheritance
        predictions.put("Blood Type", predictBloodType(fatherDNA, motherDNA));

        // Eye color inheritance (simplified)
        predictions.put("Eye Color", predictEyeColor(fatherDNA, motherDNA));

        // Disease carrier risk
        predictions.put("Cystic Fibrosis Risk",
                calculateDiseaseRisk(fatherDNA, motherDNA, "CYSTIC_FIBROSIS"));

        predictions.put("Sickle Cell Risk",
                calculateDiseaseRisk(fatherDNA, motherDNA, "SICKLE_CELL"));

        // Genetic compatibility
        predictions.put("Genetic Compatibility",
                calculateCompatibility(fatherDNA, motherDNA));

        return predictions;
    }

    private String predictBloodType(DNASequence fatherDNA, DNASequence motherDNA) {
        String fatherType = fatherDNA.predictBloodType();
        String motherType = motherDNA.predictBloodType();

        // Simplified Mendelian inheritance
        if (fatherType.equals("A") && motherType.equals("A")) {
            return "A or O";
        } else if (fatherType.equals("B") && motherType.equals("B")) {
            return "B or O";
        } else if ((fatherType.equals("A") && motherType.equals("B")) ||
                (fatherType.equals("B") && motherType.equals("A"))) {
            return "A, B, AB, or O";
        } else if (fatherType.equals("AB") || motherType.equals("AB")) {
            return "A, B, or AB";
        } else {
            return "A, B, or O";
        }
    }

    private String predictEyeColor(DNASequence fatherDNA, DNASequence motherDNA) {
        String fatherColor = fatherDNA.predictEyeColor();
        String motherColor = motherDNA.predictEyeColor();

        // Simplified inheritance
        if (fatherColor.equals("Brown") && motherColor.equals("Brown")) {
            return "Most likely Brown (75%), chance of Green/Blue (25%)";
        } else if (fatherColor.equals("Blue") && motherColor.equals("Blue")) {
            return "Blue";
        } else {
            return "Brown, Green, or Blue (mixed probability)";
        }
    }

    private String calculateDiseaseRisk(DNASequence dna1, DNASequence dna2, String disease) {
        boolean carrier1 = dna1.hasDiseaseMarker(disease);
        boolean carrier2 = dna2.hasDiseaseMarker(disease);

        if (carrier1 && carrier2) {
            return "HIGH: 25% chance affected child";
        } else if (carrier1 || carrier2) {
            return "MEDIUM: 50% chance carrier child";
        } else {
            return "LOW: Unlikely";
        }
    }

    private String calculateCompatibility(DNASequence dna1, DNASequence dna2) {
        double similarity = dna1.compareTo(dna2);

        if (similarity > 95) {
            return "Excellent (very similar genetic background)";
        } else if (similarity > 85) {
            return "Good (similar genetic background)";
        } else if (similarity > 70) {
            return "Moderate (some genetic differences)";
        } else {
            return "Poor (significant genetic differences)";
        }
    }

    // ========== PATERNITY VERIFICATION ==========

    public Analyzer.PaternityResult verifyPaternity(Person allegedChild) {
        return Analyzer.analyzePaternity(
                allegedChild.getDnaSequence(),
                father.getDnaSequence(),
                mother.getDnaSequence()
        );
    }
}